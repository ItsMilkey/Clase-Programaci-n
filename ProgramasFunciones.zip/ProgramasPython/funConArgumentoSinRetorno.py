def suma(a,b):
    suma = a + b
    print(f"La suma de los argumento es: {suma}")
num1 = int(input("Ingrese primer número: "))
num2 = int(input("Ingrese segundo número: "))
suma(num1,num2)