def suma(a,b):
    sumar = a + b
    return(sumar)
    
num1 = int(input("Ingrese primer número: "))
num2 = int(input("Ingrese segundo número: "))
print(f"La suma es: ",suma(num1,num2))