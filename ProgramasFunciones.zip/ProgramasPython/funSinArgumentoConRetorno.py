def suma():
    num1 = 3
    num2 = 5
    return(num1 + num2)
# Llamando a la función, ejecuta todo el contenido de la función
print("la suma es: ", suma())