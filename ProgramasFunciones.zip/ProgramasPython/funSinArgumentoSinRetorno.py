def funcion_sencilla():
    print("Hola, soy una función sencilla.")
    # En este segmento agregar 
    # todo lo que requieres que esta función realice
    # Sumar, restar, Convertir archivos, etc..

# Llamando a la función, ejecuta todo el contenido de la función
funcion_sencilla()
